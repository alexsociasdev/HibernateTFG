package com.dam.tfg.MotoMammiApplicationASG.services;

import org.springframework.stereotype.Service;

@Service
public interface ProcesService {
    public void readFileInfo (String pSource);
}
