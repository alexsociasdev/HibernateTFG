package com.dam.tfg.MotoMammiApplicationASG.tasks;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import java.util.List;

public class HibernateMetodos {
    public static SessionFactory sessionFactory;

    static {
            sessionFactory = new Configuration().configure().buildSessionFactory();
    }

    public static List<Provider> activeProviders() {
        Session session = sessionFactory.openSession();
        session.beginTransaction();

        Query<Provider> query = session.createQuery("FROM Provider WHERE swiAct = true", Provider.class);
        List<Provider> providers = query.list();

        session.getTransaction().commit();
        session.close();

        return providers;
    }
}

