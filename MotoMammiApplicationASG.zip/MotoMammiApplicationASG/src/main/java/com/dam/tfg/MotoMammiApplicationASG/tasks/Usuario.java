package com.dam.tfg.MotoMammiApplicationASG.tasks;

import java.text.DateFormat;
import java.util.Date;

public class Usuario {

    public String registroUsuario(){
        String respuesta = "";
        String nombre;
        String apellidos;

        return respuesta;
    }
}
