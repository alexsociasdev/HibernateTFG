package com.dam.tfg.MotoMammiApplicationASG;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MotoMammiApplicationAsgApplicationTests {

	@Test
	void contextLoads() {
	}

}
